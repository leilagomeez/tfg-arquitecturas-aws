import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const S3_CLIENT = new S3Client({ region: "us-east-1" });
const BUCKET_NAME_STR = process.env.MY_BUCKET_STR;

export const handler = async (event) => {
    console.log("BUCKET_NAME_STR", BUCKET_NAME_STR);
    const command = new GetObjectCommand({
        Bucket: BUCKET_NAME_STR,
        Key: "report.html"
    });
    const presigned_url_str = await getSignedUrl(S3_CLIENT, command, { expiresIn: 60 });
    return { "presigned_url_str": presigned_url_str };
};
