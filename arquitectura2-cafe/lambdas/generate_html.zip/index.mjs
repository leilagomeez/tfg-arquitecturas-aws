import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

const S3_CLIENT = new S3Client({ region: "us-east-1" });
const BUCKET_NAME_STR = process.env.MY_BUCKET_STR;

export const handler = async (event, context) => {
    await writeReport(await createHTML(event));
    return { "msg_str": "Report published to S3" };
};

function getCSSLink(){
    return `
      html, body, section, h1, h2, h3, h4, p{ margin: 0; padding: 0; }
      .report{ background-color: whitesmoke; padding: 0; margin: 0; position: relative; }
      .report h1{ color: #e7e2e2; font-size: 42px; text-align: center; background-color: #434343; border-bottom: 1px solid #b9b4b4; padding: 12px 24px; }
      .report h2{ font-size: 24px; }
      .report p{ font-size: 18px; padding: 12px 0px; font-style: italic; }
      .report [data-role="timestamp"]{ font-size: 16px; color: #cac6c6; position: absolute; top: 32px; right: 24px; }
      .report [data-role="supplier_info"]{ width: 90%; margin: 12px auto; color: #434343; border-bottom: 2px dotted #505951; padding-bottom: 12px; padding-top: 16px; }
      .report [data-role="bean_info"]{ display: inline-block; color: #434343; margin-bottom: 12px; border-radius: 6px; margin-right: 12px; border: 1px solid #434343; }
      .report [data-role="bean_info"] h3{ padding: 12px 24px; font-size: 20px; }
      .report [data-role="bean_info"] h4{ padding: 12px 24px; font-size: 18px; }
      .report [data-role="bean_info"] span{ padding: 12px 24px; font-size: 16px; display: block; }
    `;
}

async function createHTML(event){
    var item_obj_arr = event.my_json_arr, html_str = '', o = {}, k = {};
    html_str += '<!DOCTYPE html><html><head><title>Bean quantity report</title><style>' + getCSSLink() + '</style></head><body><section class="report"><h1>Report</h1><span data-role="timestamp">' + new Date().toLocaleTimeString() + '</span>';
    for(var i_int = 0; i_int < item_obj_arr.length; i_int++){
        o = item_obj_arr[i_int];
        html_str += '<section data-role="supplier_info"><h2>' + o.supplier_name_str + '</h2><p>' + o.supplier_address_str + " : " + o.supplier_phone_str + '</p>';
        for(var j_int = 0; j_int < o.bean_info_obj_arr.length; j_int++){
            k = o.bean_info_obj_arr[j_int];
            html_str += '<div data-role="bean_info"><h3>' + k.type_str + '</h3><h4>' + k.quantity_int.toString() + '</h4><span>' + k.product_name_str + '</span></div>';
        }
        html_str += '</section>';
    }
    html_str += '</section></body></html>';
    return html_str;
}

async function writeReport(html_str){
    await S3_CLIENT.send(new PutObjectCommand({
        Bucket: BUCKET_NAME_STR,
        Key: "report.html",
        Body: html_str,
        CacheControl: "max-age=0",
        ContentType: "text/html"
    }));
}
